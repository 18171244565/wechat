### v1.0.14 ###

# 删除商品图片表索引
ALTER TABLE `yoshop_goods_image` DROP INDEX `goods_image`;
