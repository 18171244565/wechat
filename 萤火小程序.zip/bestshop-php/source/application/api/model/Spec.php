<?php

namespace app\api\model;

use app\common\model\Spec as SpecModel;

/**
 * 规格/属性(组)模型
 * Class Spec
 * @package app\api\model
 */
class Spec extends SpecModel
{
}
