module.exports = {
  name: "萤火小程序商城",
  siteroot: "http://www.yinghuo.com/", // 必填: api地址，结尾要带/
  uniacid: "10001", // 默认即可，勿填
};
